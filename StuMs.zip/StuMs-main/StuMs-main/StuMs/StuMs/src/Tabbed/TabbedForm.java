package Tabbed;

import javax.swing.JPanel;

/**
 *
 * @author RAVEN
 */
public class TabbedForm extends JPanel{
    
    public void formOpen(){
        
    }
    
    public boolean formClose(){
        return true;
    }
    
    public void fromRefresh(){
        //  Not yet work ( next update )
    }
}
