package Login;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import net.miginfocom.swing.MigLayout;
import Main.Main;
import java.awt.Font;
import javax.swing.UIManager;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Login extends JPanel {

//    ResultSet rs;
//    Connection con;
//    PreparedStatement ps;
    public Login() {
        init();
    }

    private void init() {
        setLayout(new MigLayout("fill,insets 20", "[center]", "[center]"));
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();
        chRememberMe = new JCheckBox("Remember me");
        cmdLogin = new JButton("Login");
        JPanel panel = new JPanel(new MigLayout("wrap,fillx,insets 35 45 35 45", "fill,250:280"));
        panel.putClientProperty(FlatClientProperties.STYLE, ""
                + "arc:20;"
                + "[light]background:darken(@background,6%);"
                + "[dark]background:lighten(@background,22%)");

        txtPassword.putClientProperty(FlatClientProperties.STYLE, ""
                + "showRevealButton:true");
        cmdLogin.putClientProperty(FlatClientProperties.STYLE, ""
                + "[light]background:darken(@background,12%);"
                + "[dark]background:lighten(@background,15%);"
                + "margin:4,6,4,6;"
                + "borderWidth:0;"
                + "focusWidth:0;"
                + "innerFocusWidth:0");

        cmdLogin.addActionListener((e) -> {
            
//            try {
//                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "");
//                ps = con.prepareStatement("SELECT * from mysql");
//                rs = ps.executeQuery();
//                
//                if(rs.next()){
//                    
//                    
//                    if(rs.getString("username").equals(txtUsername.getText()) &&
//                       rs.getString("password").equals(txtPassword.getText())){
//                        
//                        
//                    }
//                }
//                
//                    
//                //  Do asaction login here
//            } catch (SQLException ex) {
//                Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
//            }
                  Main.main.showMainForm();
            
            
        });
        txtUsername.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Enter your username or email");
        txtPassword.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Enter your password");

        // Set the default font using UIManager
        Font font = new Font("Segoe UI Semibold", Font.PLAIN, 11);
        UIManager.put("defaultFont", font);

        JLabel lbTitle = new JLabel("Welcome back!", JLabel.CENTER);
        lbTitle.putClientProperty(FlatClientProperties.STYLE, ""
                + "font: bold 18");

        panel.add(lbTitle);
        panel.add(new JLabel("Username"), "gapy 17");
        panel.add(txtUsername);
        panel.add(new JLabel("Password"), "gapy 2");
        panel.add(txtPassword);
        panel.add(chRememberMe, "grow 0");
        panel.add(cmdLogin, "gapy 10");
        add(panel);
    }

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JCheckBox chRememberMe;
    private JButton cmdLogin;
}
