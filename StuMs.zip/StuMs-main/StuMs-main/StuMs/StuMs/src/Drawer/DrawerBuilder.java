package Drawer;

import Form.CaseHistory;
import Form.EducationalBack;
//import Form.Masterlist;
import Form.PersonalInfo;
//import Form.Scholarship;
//import Form.Statistics;
import Form.TestForm;
import raven.drawer.component.SimpleDrawerBuilder;
import raven.drawer.component.footer.SimpleFooterData;
import raven.drawer.component.header.SimpleHeaderData;
import raven.drawer.component.menu.MenuAction;
import raven.drawer.component.menu.MenuEvent;
import raven.drawer.component.menu.SimpleMenuOption;
//import Form.TestForm;
//import Form.Violation;
import Main.Main;
import raven.swing.AvatarIcon;
import Tabbed.WindowsTabbed;

/**
 *
 * @author RAVEN
 */
public class DrawerBuilder extends SimpleDrawerBuilder {

    @Override
    public SimpleHeaderData getSimpleHeaderData() {
        return new SimpleHeaderData()
                .setIcon(new AvatarIcon(getClass().getResource("/image/StuMs.jpg"), 100, 100, 10))
                .setTitle("Welcome to StuMs");

    }

    @Override
    public SimpleMenuOption getSimpleMenuOption() {
        String menus[][] = {
            {"~Menus~"},
            {"Personal Information"},
            {"Educational Background"},
            {"Case/Violation History"},
            {"Scholarship History"},
            {"Masterlist"},};

        String icons[] = {
            "dashboard.svg",
            "email.svg",
            "chat.svg",
            "calendar.svg",
            "ui.svg",
            "forms.svg",
            "chart.svg",
            "icon.svg",
            "page.svg",
            "logout.svg"};

        return new SimpleMenuOption()
                .setMenus(menus)
                .setIcons(icons)
                .setBaseIconPath("Drawer/Icon")
                .setIconScale(0.45f)
                .addMenuEvent(new MenuEvent() {
                    @Override
                    public void selected(MenuAction action, int index, int subIndex) {
                        if (index < 1 ) {
                            WindowsTabbed.getInstance().addTab("Personal Information", new PersonalInfo());
                        } else if (index < 2) {
                            WindowsTabbed.getInstance().addTab("Educational Background", new EducationalBack());
                        } else if (index < 3) {
                            WindowsTabbed.getInstance().addTab("Case/Violation History", new CaseHistory());
                        } else if (index < 4) {
//                            WindowsTabbed.getInstance().addTab("Scholarship History", new Scholarship());
                        } else if (index < 5) {
//                            WindowsTabbed.getInstance().addTab("Masterlist", new Masterlist());
                        } else if (index < 6) {
//                            WindowsTabbed.getInstance().addTab("Statistics Data", new Statistics());
                        }
                        else 
                            Main.main.login();
                              
                        System.out.println(index);
                    }
                });
    }

    @Override
    public SimpleFooterData getSimpleFooterData() {
        return new SimpleFooterData().setDescription("");
    }

    @Override
    public int getDrawerWidth() {
        return 225;
    }
}
